# PWS Dataset — New York City

Personal Weather Station (PWS) observations from **New York City**, USA.

## Dataset Description

| Property | Value |
|----------|-------|
| **Location** | New York City metropolitan area |
| **Source** | Weather Underground Personal Weather Stations |
| **Stations** | 37 PWS |
| **Format** | NetCDF-4 with groups ([OpenSense-1.0 PWS spec](https://github.com/OpenSenseAction/OS_data_format_conventions/blob/main/netCDF_PWS.adoc)) |

### Available Files

| File | Period | Description |
|------|--------|-------------|
| `pws_opensense_sample_jan.nc` | Jan 15–30, 2024 | Sample dataset (2 weeks) |
| `pws_wu_os.nc` | Oct 29, 2023 – Jul 1, 2024 | Full dataset (8 months) |
| `pws_metadata.csv` | — | Station locations, IDs, elevations |

### Variables

| Variable | Unit | Description |
|----------|------|-------------|
| `rainfall_amount` | mm | Precipitation per timestep |
| `rainfall_rate` | mm/h | Instantaneous rain rate |
| `temperature` | °C | Air temperature |
| `relative_humidity` | % | Relative humidity |
| `wind_velocity` | m/s | Wind speed |
| `wind_direction` | ° | Wind direction |
| `air_pressure` | hPa | Atmospheric pressure |

### Data Format

Data is stored in **NetCDF-4 with groups** following the [OpenSense-1.0 PWS specification](https://github.com/OpenSenseAction/OS_data_format_conventions/blob/main/netCDF_PWS.adoc):

- Each station is a separate **group** (e.g., `KNYNEWYO1805`)
- Each group contains time-indexed variables
- Coordinates stored as group attributes

---

## License & Terms of Use

### Dataset License

This dataset is licensed under **[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)** — free to use with attribution.

### Data Source Terms

The underlying PWS data is sourced from [Weather Underground](https://www.wunderground.com/) (a division of [The Weather Company](https://www.weathercompany.com/)).

Per [Weather Underground Terms of Use](https://www.wunderground.com/company/legal/):
- **Personal, non-commercial use only**
- No redistribution without permission
- Attribution to Weather Underground and PWS station operators required

### Attribution

> Weather Underground community weather station operators are acknowledged for providing the original observations. Data formatted to OpenSense-1.0 standard by Dror Jacoby (Tel Aviv University / Columbia University).

---

## Analysis Notebook

This repository includes **`pws_analysis.ipynb`** — a Jupyter notebook for reading and visualizing the PWS data.

### Features

- Load NetCDF files with automatic group-to-xarray conversion
- Raw rainfall event visualization
- Multi-variable time series plots
- Station map (matplotlib / contextily)
- Accumulated rainfall grid plots
- Ensemble statistics (mean, median, min, max, range)
- Summary tables and histograms

### Requirements
```
netCDF4
xarray
pandas
numpy
matplotlib
contextily (optional)
```

### Quick Start
```python
# Load data
ds_pws, pws_data = load_pws_data('pws_opensense_sample_jan.nc')

# Plot ensemble
plot_ensemble(pws_data, variable='rainfall_amount',
              start_date='2024-01-15', end_date='2024-01-30')

# Close when done
ds_pws.close()
```

---

## Related Resources

### OpenMesh Project

This PWS dataset is part of the **OpenMesh** project — a wireless signal dataset for opportunistic urban weather sensing in New York City. Active development tools, datasets, and codes are accessible through the OpenMesh GitHub repository, the Zenodo data archive, and the OpenSense toolchain.

| Resource | Link |
|----------|------|
| **Repository** | [github.com/drorjac/OpenMesh](https://github.com/drorjac/OpenMesh) |
| **Full Dataset (Zenodo)** | [doi.org/10.5281/zenodo.15287692](https://zenodo.org/records/15287692) |
| **Paper (ESSD)** | [doi.org/10.5194/essd-2025-238](https://doi.org/10.5194/essd-2025-238) |

The OpenMesh repository includes:
- Download tools for fetching data from Zenodo
- Data fetching scripts for NOAA ASOS and Weather Underground APIs
- Example notebooks for analysis
- Microwave link dataset from NYC Mesh network

### Quality Control Tools

| Package | Description |
|---------|-------------|
| [pypwsqc](https://github.com/OpenSenseAction/pypwsqc) | QC filters for PWS data (Faulty Zero, High Influx, Spatial Outlier) |
| [poligrain](https://github.com/OpenSenseAction/poligrain) | Tools for point, line, and gridded rainfall sensor data |

### Data Format Standards

- [OpenSense-1.0 PWS Format](https://github.com/OpenSenseAction/OS_data_format_conventions/blob/main/netCDF_PWS.adoc)
- [OpenSense Action](https://opensenseaction.eu/)

---


## Acknowledgments

- Weather Underground community weather station operators
- The Weather Company
- NYC Community Mesh Network
- [OpenSense Action](https://opensenseaction.eu/)

**Affiliations:** Tel Aviv University (CellEnMon Lab), Columbia University (WiMNet Lab)

---

## Contact

- **Issues:** [github.com/drorjac/OpenMesh/issues](https://github.com/drorjac/OpenMesh/issues)
- **ESSD Discussion:** [essd.copernicus.org/preprints/essd-2025-238/#discussion](https://essd.copernicus.org/preprints/essd-2025-238/#discussion)